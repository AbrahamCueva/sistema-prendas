// resources/js/app.js
import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();

// Importa Chart.js
import Chart from 'chart.js/auto';
window.Chart = Chart;
